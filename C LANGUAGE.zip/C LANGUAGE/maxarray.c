//wap to print  orig and maximum element in array
#include <stdio.h>