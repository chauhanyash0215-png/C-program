#include<stdio.h>

int main() {
    printf("Hello, World!\n");
    int x;
    scanf("%d" , &x);
    printf("You entered: %d\n", x);
    return 0;
}