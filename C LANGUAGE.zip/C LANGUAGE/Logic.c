# include <studio.h>
int main()
{
    int x,y,z;
    system( "cls");
    print("Enter two integers:);
        sacf("%d %d, & x,&y);
    z=x+y
    print ("The sum of %d and %d" = %d,x,y,z);
        return0;
}