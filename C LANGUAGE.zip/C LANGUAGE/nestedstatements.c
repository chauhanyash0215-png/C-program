//wap to check you are indian if yes thrn check ur age if age>18 then you are eligible for vote otherwise not eligible for vote
#include<stdio.h>
int main()
{
    char c;
    int age;
    printf("Enter character'I' as 'i' if you are indian: ");
    scanf("%c", &c);
    if(c=='I' || c=='i')
    {
        printf(" Great!Enter your age: ");
        scanf("%d", &age);
        if(age>=18)
        {
            printf("The age is %d. You are eligible for vote.",age);
        }
        else
        {
            printf("You are under age.");
        }
    }
    else
    {
        printf("You are not indian.");
    }
    return 0;
}