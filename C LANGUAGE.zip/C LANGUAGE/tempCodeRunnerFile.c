
        printf("Consonant");