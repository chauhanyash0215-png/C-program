//wap to print digits of a number
#include<stdio.h>
int main()
{
    int num;
    printf("Enter a number: ");
    scanf("%d",&num);
    printf("Digits of the number are: ");
    while(num > 0)
    {
        printf("%d ",num % 10);
        num = num / 10;
    }
    return 0;
}   