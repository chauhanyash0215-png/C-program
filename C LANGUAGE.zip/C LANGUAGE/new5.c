#include<stdio.h>
int main()
{
      float f;
      printf("Enter any character");
      scanf("%f ,&f");
      int e = (int)f;
      printf("The character %f ASCII value is %d, f,f");
      return 0;
}