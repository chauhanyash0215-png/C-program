#include<stdio.h>
int main()
{
    int n = 10;
    int x = n++;
    printf("The value of n = %d\n",n);
    int y = ++n;
    printf("The value of x = %d\n",x);
    printf("The value of y = %d\n",y);
    return 0;
}
