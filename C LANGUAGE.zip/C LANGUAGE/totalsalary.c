//wap to calculate total salary(ts)
ts = bs + da + to - pf;