#include <stdio.h>
int main()
{
    int spoint = 0, i = 1;
    while(i<=10)
    {
        even =
        spoint+=i;
        i++;
    }
    printf("Sum of first 10 n-natural number is %d\n", spoint);
    return 0;
}