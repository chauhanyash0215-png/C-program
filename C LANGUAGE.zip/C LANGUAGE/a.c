#include <stdio.h>
int main ()
{
printf("Akshay Chauhan");
return 0;
}
